import logo from './logo.svg';
import './App.css';
import Board from "./components/Board";
import Column from "./components/Column";

function App() {
  return (
    <div className="App">
        <Board />
    </div>
  );
}

export default App;
